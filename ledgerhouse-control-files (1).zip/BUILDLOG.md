# BUILDLOG.md — Append-only session log. One entry per agent session.

Format:
## [date] | [agent: Claude Code / Codex / Gemini / Perplexity] | [branch]
- Task attempted:
- Files touched:
- Tests run and result:
- Stage gate progress:
- Handover note:

(first entry goes here)
