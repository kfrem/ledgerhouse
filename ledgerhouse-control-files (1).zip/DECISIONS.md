# DECISIONS.md — Append-only architectural decision log. Never edit past entries.

## D-001 | 2026-07-10 | Stack
Django modular monolith + PostgreSQL + server-rendered templates (PWA). Reason: test tooling, ORM integrity, admin, founder familiarity. Decided in Plan v2.1 Section 7.1. Approved: Godfred.

## D-002 | 2026-07-10 | AI posting rule
AI classification proposes only, with confidence and stored reason. Only deterministic rules or human review create journals. Approved: Godfred (panel consensus).

## D-003 | 2026-07-10 | Internationalisation boundary
jurisdiction, currency, tax_registration, accounting_basis are first-class fields; tax codes are configuration tables; UK is the first plugin pack. Approved: Godfred.

(append new entries below in the same format: D-00N | date | title | decision | reason | approved by)
