# STATE.md — Single source of current truth. Update at the END of every session.

## Current stage
Stage 0 — Scope freeze and synthetic company factory (PLAN.md Section 6.2, weeks 1–3)
Branch: stage-0-foundation

## Done
- (nothing yet — project initialised)

## In progress
- (empty)

## Next (in order)
1. Initialise Git repository, Docker Compose (Django + PostgreSQL), CI running pytest on every push.
2. Write the written exclusions list (from PLAN.md Section 5.2) into DECISIONS.md.
3. Build the synthetic company factory: three companies (care provider, consultancy, simple trader), VAT and non-VAT variants, deterministic from a seed.
4. Store expected results as fixtures: journals, trial balance, VAT totals, ageings, reconciliation states, audit events, rejection messages.

## Stage 0 exit gate (do not proceed to Stage 1 until ALL true)
- [ ] Datasets deterministic from seed
- [ ] Expected results stored as fixtures
- [ ] CI green on the fixture suite
- [ ] Exclusions list signed off in DECISIONS.md

## Blockers
- (none)

## Notes for the next agent
- (write anything the next agent must know that is not obvious from the code)
